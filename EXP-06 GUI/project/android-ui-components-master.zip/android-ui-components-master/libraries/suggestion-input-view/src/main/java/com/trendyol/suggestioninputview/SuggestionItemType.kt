package com.trendyol.suggestioninputview

enum class SuggestionItemType {
    SELECTABLE, INPUT
}