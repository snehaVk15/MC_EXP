object Components {

    const val ratingBar = ":libraries:rating-bar"
    const val dialogs = ":libraries:dialogs"
    const val imageSlider = ":libraries:image-slider"
    const val phoneNumber = ":libraries:phonenumber"
    const val toolbar = ":libraries:toolbar"
    const val suggestionInputView = ":libraries:suggestion-input-view"
    const val cardInputView = ":libraries:card-input-view"
    const val quantityPickerView = ":libraries:quantity-picker-view"
    const val timelineView = ":libraries:timeline-view"
    const val touchDelegator = ":libraries:touch-delegator"
    const val fitOptionMessageView = ":libraries:fit-option-message-view"

}