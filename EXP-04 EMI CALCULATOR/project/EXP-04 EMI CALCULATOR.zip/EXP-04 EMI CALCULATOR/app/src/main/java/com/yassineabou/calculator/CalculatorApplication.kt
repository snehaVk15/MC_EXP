package com.yassineabou.calculator

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CalculatorApplication : Application()
